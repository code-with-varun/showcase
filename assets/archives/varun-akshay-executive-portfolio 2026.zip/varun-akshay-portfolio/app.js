/* 
  VARUN AKSHAY PORTFOLIO SYSTEM JAVASCRIPT
*/

// MASTER SKILLS & KEYWORD DATASET
const SKILLS_DATA = [
  // MIS & BFSI
  { name: 'MIS Reporting', category: 'mis', keyword: true },
  { name: 'BFSI Collections', category: 'mis', keyword: true },
  { name: 'Vendor Management', category: 'mis', keyword: true },
  { name: 'Vendor Payout Validation', category: 'mis', keyword: true },
  { name: 'Recovery Agency Ops', category: 'mis', keyword: true },
  { name: 'Call Center Billing QC', category: 'mis', keyword: true },
  { name: 'Credit Card Billing', category: 'mis', keyword: true },
  { name: 'Operations Analytics', category: 'mis', keyword: true },
  { name: 'Productivity Tracking', category: 'mis', keyword: true },
  { name: 'KPI Monitoring', category: 'mis', keyword: true },
  { name: 'Root Cause Analysis (RCA)', category: 'mis', keyword: true },
  { name: 'SLA Monitoring', category: 'mis', keyword: true },
  { name: 'Workforce Reporting', category: 'mis', keyword: true },

  // Advanced Excel
  { name: 'Advanced Excel', category: 'excel', keyword: true },
  { name: 'VLOOKUP / XLOOKUP', category: 'excel', keyword: true },
  { name: 'INDEX MATCH', category: 'excel', keyword: true },
  { name: 'Nested IF / IFS / IFERROR', category: 'excel', keyword: true },
  { name: 'COUNTIFS / SUMIFS', category: 'excel', keyword: true },
  { name: 'Pivot Tables & Charts', category: 'excel', keyword: true },
  { name: 'Conditional Formatting', category: 'excel', keyword: true },
  { name: 'Dashboard Development', category: 'excel', keyword: true },
  { name: 'Financial & HR MIS', category: 'excel', keyword: true },

  // Databases & SQL
  { name: 'SQL', category: 'db', keyword: true },
  { name: 'MS SQL Server', category: 'db', keyword: true },
  { name: 'MySQL', category: 'db', keyword: true },
  { name: 'MongoDB', category: 'db', keyword: true },
  { name: 'MS Access', category: 'db', keyword: true },
  { name: 'Complex Queries & JOINs', category: 'db', keyword: true },

  // Automation & AI
  { name: 'Billing Automation', category: 'automation', keyword: true },
  { name: 'Process Automation', category: 'automation', keyword: true },
  { name: 'Reporting Automation', category: 'automation', keyword: true },
  { name: 'Generative AI Concepts', category: 'automation', keyword: true },
  { name: 'Prompt Engineering', category: 'automation', keyword: true },
  { name: 'ChatGPT / Gemini / Copilot', category: 'automation', keyword: true },
  { name: 'RAG & AI Agent Concepts', category: 'automation', keyword: true },
  { name: 'Motion Comics Learning', category: 'automation', keyword: true },

  // Full Stack Dev
  { name: 'HTML5 & CSS3', category: 'fullstack', keyword: true },
  { name: 'JavaScript (ES6+)', category: 'fullstack', keyword: true },
  { name: 'React.js', category: 'fullstack', keyword: true },
  { name: 'Node.js & Express.js', category: 'fullstack', keyword: true },
  { name: 'PHP & Laravel', category: 'fullstack', keyword: true },
  { name: 'CodeIgniter & WordPress', category: 'fullstack', keyword: true },
  { name: 'REST APIs & Git/GitHub', category: 'fullstack', keyword: true },

  // Retail & Operations
  { name: 'Store Management (Jockey)', category: 'retail', keyword: true },
  { name: 'Sales Management (+15% Growth)', category: 'retail', keyword: true },
  { name: 'Inventory & Vendor Supply', category: 'retail', keyword: true },
  { name: 'Staff Training (8+ Staff)', category: 'retail', keyword: true },
  { name: 'Healthcare Claims Processing', category: 'retail', keyword: true }
];

const RECRUITER_KEYWORDS = [
  "MIS Analyst", "Reporting Analyst", "BFSI Reporting", "BFSI Collections",
  "Collections MIS", "Operations Analytics", "Vendor Management", "Vendor Payout",
  "Recovery Agency Operations", "Call Center Billing", "Credit Card Billing",
  "Billing QC", "Data Validation", "Advanced Excel", "Dashboard Development",
  "MIS Reporting", "Reporting Automation", "Process Improvement", "Stakeholder Management",
  "SQL", "Automation", "AI", "Generative AI", "Business Reporting", "Performance Reporting",
  "Productivity Dashboard", "Operations Reporting", "Workforce Analytics", "Root Cause Analysis",
  "Process Documentation", "Cross Training", "SPOC", "Leadership Readiness", "Team Management"
];

// PROJECT MODAL DETAILS DIALOG CONTENT
const PROJECT_DETAILS = {
  'mis-billing': {
    title: 'Recovery Agency & Billing Automation',
    badge: 'MIS Automation',
    badgeClass: 'mis-badge',
    description: 'Designed and deployed automated invoice validation and vendor payout calculations for Datamatics BFSI recovery agencies.',
    highlights: [
      'Automated reconciliation of multi-vendor recovery agency claims.',
      'Reduced manual verification cycle time by over 60%.',
      'Integrated error-checking logic for Call Center & Credit Card billing QC.'
    ],
    tech: ['Advanced Excel', 'XLOOKUP/VLOOKUP', 'Pivot Automation', 'Data Cleaning']
  },
  'mis-collection': {
    title: 'BFSI Collection Reporting Dashboard',
    badge: 'MIS Analytics',
    badgeClass: 'mis-badge',
    description: 'Centralized collection cost data requirements (including IDFC requirements) into interactive management dashboards.',
    highlights: [
      'Real-time tracking of agency payout trends and daily recovery metrics.',
      'Automated performance visibility for management presentations.',
      'Comprehensive SLA and escalation monitoring triggers.'
    ],
    tech: ['Excel Dashboards', 'MS SQL', 'Aggregation Queries', 'KPI Monitoring']
  },
  'app-ispark': {
    title: 'ISPARK Operations Web Application',
    badge: 'Full Stack MERN',
    badgeClass: 'web-badge',
    description: 'Enterprise web application for employee productivity tracking, process task logs, and automated team performance visibility.',
    highlights: [
      'Built interactive React frontend with responsive glassmorphism UI.',
      'Express.js & Node.js backend with MongoDB database integration.',
      'Role-based access control and live task status dashboards.'
    ],
    tech: ['React', 'Node.js', 'Express.js', 'MongoDB', 'REST API']
  },
  'app-vis-hr': {
    title: 'VIS HR & Billable Hours Portal',
    badge: 'PHP Full Stack',
    badgeClass: 'web-badge',
    description: 'Developed during Velan Info Services tenure to manage employee attendance, billable hours reports, and accurate client invoicing.',
    highlights: [
      'Delivered 3+ custom reporting modules for management oversight.',
      'Seamless database query execution with MySQL backend.',
      'Custom Bootstrap & JavaScript user interface.'
    ],
    tech: ['PHP', 'CodeIgniter', 'MySQL', 'Bootstrap', 'JavaScript']
  },
  'app-powerbooks': {
    title: 'PowerBooks Financial Accounting System',
    badge: 'Laravel Full Stack',
    badgeClass: 'web-badge',
    description: 'Web application built for small businesses to manage ledgers, revenue tracking, inventory accounts, and invoice generation.',
    highlights: [
      'Automated financial summary reporting and sales tax calculations.',
      'Secure authentication and database relationship models.',
      'Responsive design for desktop and mobile devices.'
    ],
    tech: ['Laravel', 'PHP', 'MySQL', 'REST API', 'Tailwind/CSS']
  },
  'game-tanks': {
    title: 'Battle Tanks 2D Arcade Game',
    badge: 'JavaScript Canvas',
    badgeClass: 'game-badge',
    description: 'Retro arcade-style tank combat game engineered completely with Vanilla HTML5 Canvas and Object-Oriented JavaScript physics.',
    highlights: [
      'Custom collision detection, projectile physics, and score tracking.',
      'Enemy AI movement and smooth 60FPS animation rendering loop.',
      'Audio synthesis and particle splash visual effects.'
    ],
    tech: ['HTML5 Canvas', 'JavaScript ES6', 'OOP Game Engine', 'CSS3']
  }
};

// DOM CONTENT LOADED INITIALIZATION
document.addEventListener('DOMContentLoaded', () => {
  initRoleTyper();
  renderSkillPills('all');
  renderRecruiterTags();
  initKeywordSearch();
  initCategoryTabs();
  initProjectFilters();
  initRecruiterModeToggle();
});

// ROLE TYPER ANIMATION
function initRoleTyper() {
  const roles = [
    'MIS & Reporting Analyst',
    'Automation Specialist',
    'Full Stack Developer',
    'Future AI Operations Specialist'
  ];
  const typerElem = document.getElementById('role-typer');
  if (!typerElem) return;

  let roleIdx = 0;
  let charIdx = 0;
  let isDeleting = false;

  function typeStep() {
    const currentRole = roles[roleIdx];

    if (isDeleting) {
      typerElem.textContent = currentRole.substring(0, charIdx - 1);
      charIdx--;
    } else {
      typerElem.textContent = currentRole.substring(0, charIdx + 1);
      charIdx++;
    }

    let delay = isDeleting ? 40 : 80;

    if (!isDeleting && charIdx === currentRole.length) {
      delay = 2000;
      isDeleting = true;
    } else if (isDeleting && charIdx === 0) {
      isDeleting = false;
      roleIdx = (roleIdx + 1) % roles.length;
      delay = 400;
    }

    setTimeout(typeStep, delay);
  }

  typeStep();
}

// RENDER SKILL PILLS
function renderSkillPills(categoryFilter = 'all', searchQuery = '') {
  const container = document.getElementById('skills-pills-container');
  if (!container) return;

  container.innerHTML = '';

  const filtered = SKILLS_DATA.filter(item => {
    const matchesCat = (categoryFilter === 'all') || (item.category === categoryFilter);
    const matchesSearch = searchQuery === '' || item.name.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  filtered.forEach(skill => {
    const pill = document.createElement('div');
    pill.className = `skill-pill ${searchQuery && skill.name.toLowerCase().includes(searchQuery.toLowerCase()) ? 'matched-highlight' : ''}`;
    pill.innerHTML = `<i data-lucide="check" style="width:14px; height:14px;"></i> <span>${skill.name}</span>`;
    container.appendChild(pill);
  });

  if (window.lucide) lucide.createIcons();

  const matchCountElem = document.getElementById('search-match-count');
  if (matchCountElem) {
    matchCountElem.textContent = `Showing ${filtered.length} of ${SKILLS_DATA.length} Skills & Capabilities`;
  }
}

// RENDER RECRUITER TAG CLOUD
function renderRecruiterTags(searchQuery = '') {
  const container = document.getElementById('recruiter-tag-cloud');
  if (!container) return;

  container.innerHTML = '';

  RECRUITER_KEYWORDS.forEach(tag => {
    const isMatch = searchQuery && tag.toLowerCase().includes(searchQuery.toLowerCase());
    const pill = document.createElement('span');
    pill.className = `tag-pill ${isMatch ? 'matched-highlight' : ''}`;
    pill.textContent = `# ${tag}`;
    container.appendChild(pill);
  });
}

// KEYWORD SEARCH ENGINE
function initKeywordSearch() {
  const searchInput = document.getElementById('keyword-search-input');
  const clearBtn = document.getElementById('clear-search-btn');

  if (!searchInput) return;

  searchInput.addEventListener('input', (e) => {
    const query = e.target.value.trim();
    
    if (clearBtn) clearBtn.hidden = (query === '');

    // Get active category tab
    const activeTab = document.querySelector('.skill-category-tabs .tab-btn.active');
    const category = activeTab ? activeTab.dataset.category : 'all';

    renderSkillPills(category, query);
    renderRecruiterTags(query);
  });

  if (clearBtn) {
    clearBtn.addEventListener('click', () => {
      searchInput.value = '';
      clearBtn.hidden = true;
      const activeTab = document.querySelector('.skill-category-tabs .tab-btn.active');
      const category = activeTab ? activeTab.dataset.category : 'all';
      renderSkillPills(category, '');
      renderRecruiterTags('');
    });
  }
}

// CATEGORY TABS
function initCategoryTabs() {
  const tabs = document.querySelectorAll('.skill-category-tabs .tab-btn');
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');

      const category = tab.dataset.category;
      const searchInput = document.getElementById('keyword-search-input');
      const query = searchInput ? searchInput.value.trim() : '';

      renderSkillPills(category, query);
    });
  });
}

// PROJECT FILTER TABS
function initProjectFilters() {
  const filterTabs = document.querySelectorAll('.project-filter-bar .proj-tab');
  const projectCards = document.querySelectorAll('.projects-grid .project-card');

  filterTabs.forEach(tab => {
    tab.addEventListener('click', () => {
      filterTabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');

      const filter = tab.dataset.filter;

      projectCards.forEach(card => {
        if (filter === 'all' || card.dataset.category === filter) {
          card.style.display = 'flex';
        } else {
          card.style.display = 'none';
        }
      });
    });
  });
}

// RECRUITER HIGHLIGHT MODE TOGGLE
function initRecruiterModeToggle() {
  const toggleBtn = document.getElementById('recruiter-toggle-btn');
  if (!toggleBtn) return;

  toggleBtn.addEventListener('click', () => {
    document.body.classList.toggle('recruiter-mode-active');

    const isActive = document.body.classList.contains('recruiter-mode-active');
    toggleBtn.classList.toggle('active', isActive);

    if (isActive) {
      toggleBtn.querySelector('span').textContent = 'Recruiter Mode ON';
    } else {
      toggleBtn.querySelector('span').textContent = 'Recruiter Mode';
    }
  });
}

// CONTACT MODAL CONTROL
function openContactModal() {
  const dialog = document.getElementById('contact-dialog');
  if (dialog && typeof dialog.showModal === 'function') {
    dialog.showModal();
  }
}

function closeContactModal() {
  const dialog = document.getElementById('contact-dialog');
  if (dialog && typeof dialog.close === 'function') {
    dialog.close();
  }
}

// PROJECT MODAL CONTROL
function openProjectModal(projectId) {
  const dialog = document.getElementById('project-modal');
  const titleElem = document.getElementById('modal-proj-title');
  const bodyElem = document.getElementById('modal-proj-body');

  const proj = PROJECT_DETAILS[projectId];
  if (!proj || !dialog) return;

  titleElem.innerHTML = `<span class="project-badge ${proj.badgeClass}">${proj.badge}</span> ${proj.title}`;

  let highlightsHtml = proj.highlights.map(h => `<li><i data-lucide="check-circle-2"></i> ${h}</li>`).join('');
  let techHtml = proj.tech.map(t => `<span>${t}</span>`).join('');

  bodyElem.innerHTML = `
    <p class="margin-bottom-md" style="font-size:1rem; color:var(--text-muted);">${proj.description}</p>
    
    <h4 style="margin-bottom:0.75rem; color:var(--cyan);">Key Highlights & Accomplishments:</h4>
    <ul class="identity-list margin-bottom-md">
      ${highlightsHtml}
    </ul>

    <h4 style="margin-bottom:0.75rem; color:var(--cyan);">Technologies Used:</h4>
    <div class="tech-stack-pills">
      ${techHtml}
    </div>
  `;

  if (window.lucide) lucide.createIcons();

  dialog.showModal();
}

function closeProjectModal() {
  const dialog = document.getElementById('project-modal');
  if (dialog && typeof dialog.close === 'function') {
    dialog.close();
  }
}

// COPY TO CLIPBOARD HELPER
function copyToClipboard(text, btnElem) {
  navigator.clipboard.writeText(text).then(() => {
    const originalHtml = btnElem.innerHTML;
    btnElem.innerHTML = '<i data-lucide="check" style="color:var(--emerald);"></i> Copied!';
    if (window.lucide) lucide.createIcons();
    setTimeout(() => {
      btnElem.innerHTML = originalHtml;
      if (window.lucide) lucide.createIcons();
    }, 2000);
  }).catch(err => {
    console.error('Copy error:', err);
  });
}
