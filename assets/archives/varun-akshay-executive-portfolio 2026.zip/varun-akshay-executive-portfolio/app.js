/* 
  EXECUTIVE OBSIDIAN & EMERALD PORTFOLIO JAVASCRIPT ENGINE
  Includes 100% of all Master Profile Backup parameters
*/

// COMPLETE SKILLS MATRIX DATASET (All 70+ Skills across 7 Categories)
const EXEC_SKILLS = [
  // Core Business (26)
  { name: 'MIS Reporting', cat: 'business' },
  { name: 'Reporting Analyst Work', cat: 'business' },
  { name: 'BFSI Collections', cat: 'business' },
  { name: 'Collection Analytics', cat: 'business' },
  { name: 'Vendor Management', cat: 'business' },
  { name: 'Vendor Payout Management', cat: 'business' },
  { name: 'Recovery Agency Operations', cat: 'business' },
  { name: 'Call Center Billing', cat: 'business' },
  { name: 'Credit Card Billing', cat: 'business' },
  { name: 'Billing QC', cat: 'business' },
  { name: 'Operations Analytics', cat: 'business' },
  { name: 'Productivity Tracking', cat: 'business' },
  { name: 'Performance Reporting', cat: 'business' },
  { name: 'Management Reporting', cat: 'business' },
  { name: 'Process Documentation', cat: 'business' },
  { name: 'Presentation Skills', cat: 'business' },
  { name: 'Stakeholder Management', cat: 'business' },
  { name: 'Data Validation', cat: 'business' },
  { name: 'Root Cause Analysis (RCA)', cat: 'business' },
  { name: 'Process Improvement', cat: 'business' },
  { name: 'SLA Monitoring', cat: 'business' },
  { name: 'Escalation Handling', cat: 'business' },
  { name: 'Workforce Reporting', cat: 'business' },
  { name: 'Team Coordination', cat: 'business' },
  { name: 'Knowledge Transfer (KT)', cat: 'business' },
  { name: 'Cross Training', cat: 'business' },

  // Advanced Excel (24)
  { name: 'Advanced Excel', cat: 'excel' },
  { name: 'VLOOKUP', cat: 'excel' },
  { name: 'XLOOKUP', cat: 'excel' },
  { name: 'INDEX MATCH', cat: 'excel' },
  { name: 'IF / IFS / IFERROR', cat: 'excel' },
  { name: 'COUNTIF / COUNTIFS', cat: 'excel' },
  { name: 'SUMIF / SUMIFS', cat: 'excel' },
  { name: 'Pivot Tables', cat: 'excel' },
  { name: 'Pivot Charts', cat: 'excel' },
  { name: 'Conditional Formatting', cat: 'excel' },
  { name: 'Data Validation (Excel)', cat: 'excel' },
  { name: 'Dashboard Creation', cat: 'excel' },
  { name: 'MIS Reporting (Excel)', cat: 'excel' },
  { name: 'Data Cleaning', cat: 'excel' },
  { name: 'Report Automation', cat: 'excel' },
  { name: 'Performance Reports', cat: 'excel' },
  { name: 'Financial MIS', cat: 'excel' },
  { name: 'Sales MIS', cat: 'excel' },
  { name: 'HR MIS', cat: 'excel' },
  { name: 'Productivity MIS', cat: 'excel' },

  // Database Skills (14)
  { name: 'SQL', cat: 'db' },
  { name: 'MS SQL Server', cat: 'db' },
  { name: 'MS Access', cat: 'db' },
  { name: 'MySQL', cat: 'db' },
  { name: 'MongoDB', cat: 'db' },
  { name: 'Database Reporting', cat: 'db' },
  { name: 'Query Writing', cat: 'db' },
  { name: 'SELECT / WHERE', cat: 'db' },
  { name: 'GROUP BY / HAVING', cat: 'db' },
  { name: 'JOINs (Inner/Outer)', cat: 'db' },
  { name: 'Aggregation Functions', cat: 'db' },

  // Analytics Skills (15)
  { name: 'KPI Monitoring', cat: 'analytics' },
  { name: 'Performance Analytics', cat: 'analytics' },
  { name: 'Operations Analytics', cat: 'analytics' },
  { name: 'Reporting Analytics', cat: 'analytics' },
  { name: 'Business Analytics', cat: 'analytics' },
  { name: 'Collection Analytics', cat: 'analytics' },
  { name: 'Productivity Analytics', cat: 'analytics' },
  { name: 'Vendor Analytics', cat: 'analytics' },
  { name: 'Trend Analysis', cat: 'analytics' },
  { name: 'Data Interpretation', cat: 'analytics' },
  { name: 'Management Dashboards', cat: 'analytics' },

  // Automation Skills (9)
  { name: 'Billing Automation', cat: 'automation' },
  { name: 'Reporting Automation', cat: 'automation' },
  { name: 'Excel Automation', cat: 'automation' },
  { name: 'Process Improvement', cat: 'automation' },
  { name: 'Dashboard Automation', cat: 'automation' },
  { name: 'Data Consolidation', cat: 'automation' },
  { name: 'Performance Tracking Automation', cat: 'automation' },
  { name: 'AI Assisted Productivity', cat: 'automation' },
  { name: 'Workflow Optimization', cat: 'automation' },

  // AI Skills (14)
  { name: 'Prompt Engineering', cat: 'ai' },
  { name: 'ChatGPT Usage', cat: 'ai' },
  { name: 'Gemini Usage', cat: 'ai' },
  { name: 'Microsoft Copilot Usage', cat: 'ai' },
  { name: 'AI Productivity Workflows', cat: 'ai' },
  { name: 'Generative AI Concepts', cat: 'ai' },
  { name: 'AI Research', cat: 'ai' },
  { name: 'AI Assisted Reporting', cat: 'ai' },
  { name: 'AI Assisted Automation', cat: 'ai' },
  { name: 'AI Content Creation', cat: 'ai' },
  { name: 'Motion Comic Learning', cat: 'ai' },
  { name: 'AI Agent Concepts', cat: 'ai' },
  { name: 'RAG Concepts', cat: 'ai' },

  // Full Stack Dev Skills (18)
  { name: 'HTML & CSS', cat: 'dev' },
  { name: 'Bootstrap', cat: 'dev' },
  { name: 'JavaScript (ES6+)', cat: 'dev' },
  { name: 'React', cat: 'dev' },
  { name: 'Node.js & Express.js', cat: 'dev' },
  { name: 'MongoDB (MERN)', cat: 'dev' },
  { name: 'REST API', cat: 'dev' },
  { name: 'Git & GitHub', cat: 'dev' },
  { name: 'PHP', cat: 'dev' },
  { name: 'Laravel', cat: 'dev' },
  { name: 'CodeIgniter', cat: 'dev' },
  { name: 'WordPress', cat: 'dev' },
  { name: 'Web App Development', cat: 'dev' },
  { name: 'Responsive Design', cat: 'dev' }
];

// RECRUITER KEYWORDS (35+)
const EXEC_RECRUITER_TAGS = [
  "MIS Analyst", "Reporting Analyst", "BFSI Reporting", "BFSI Collections",
  "Collections MIS", "Operations Analytics", "Vendor Management", "Vendor Payout",
  "Recovery Agency Operations", "Call Center Billing", "Credit Card Billing",
  "Billing QC", "Data Validation", "Advanced Excel", "Dashboard Development",
  "MIS Reporting", "Reporting Automation", "Process Improvement", "Stakeholder Management",
  "SQL", "Automation", "AI", "Generative AI", "Business Reporting", "Performance Reporting",
  "Productivity Dashboard", "Operations Reporting", "Workforce Analytics", "Root Cause Analysis",
  "Process Documentation", "Cross Training", "SPOC", "Leadership Readiness", "Team Management"
];

// ALL 17 PROJECTS DATASET
const EXEC_PROJECTS = [
  // MIS Projects (8)
  { id: 'mis-1', name: 'Recovery Agency Billing Automation', type: 'mis', desc: 'Automated invoice validation and vendor payout calculations for recovery agency partners.', tags: ['Advanced Excel', 'VLOOKUP/XLOOKUP', 'Pivot Tables'] },
  { id: 'mis-2', name: 'Call Center Billing Automation QC', type: 'mis', desc: 'Quality control automation system verifying billable hours, rates, and SLA benchmarks.', tags: ['Excel Automation', 'QC Validation', 'SQL'] },
  { id: 'mis-3', name: 'Credit Card Billing Automation', type: 'mis', desc: 'Streamlined billing automation for credit card recovery processing and exception handling.', tags: ['Data Cleaning', 'Formula Logic', 'Reporting'] },
  { id: 'mis-4', name: 'Payout MIS & Vendor Validation', type: 'mis', desc: 'Comprehensive payout MIS tracking system for vendor payouts and financial reconciliation.', tags: ['Financial MIS', 'Data Validation', 'Dashboards'] },
  { id: 'mis-5', name: 'BFSI Collection Reporting Dashboard', type: 'mis', desc: 'Centralized collection dashboard tracking IDFC cost requirements and agency recovery rates.', tags: ['Collection MIS', 'IDFC Portal', 'KPI Tracking'] },
  { id: 'mis-6', name: 'Performance and HR MIS', type: 'mis', desc: 'Cross-functional performance tracking dashboard linking HR productivity metrics with SLA outputs.', tags: ['HR MIS', 'Workforce Analytics', 'Pivot Charts'] },
  { id: 'mis-7', name: 'Sales MIS Reporting System', type: 'mis', desc: 'Sales MIS developed for weekly and monthly performance decision support.', tags: ['Sales MIS', 'Trend Analysis', 'Excel'] },
  { id: 'mis-8', name: 'Team Productivity Tracking Dashboard', type: 'mis', desc: 'Operational dashboard providing clear team performance visibility and timesheet tracking.', tags: ['Productivity MIS', 'Operations Reporting', 'KPI Monitoring'] },

  // Technical Projects (7)
  { id: 'tech-1', name: 'ISPARK Web Application', type: 'tech', desc: 'Operational workflow web app for internal productivity and task tracking.', tags: ['React', 'Node.js', 'Express', 'MongoDB'] },
  { id: 'tech-2', name: 'Pondynet Web App', type: 'tech', desc: 'Local business directory & community web portal for Puducherry region.', tags: ['JavaScript', 'HTML5/CSS3', 'PHP'] },
  { id: 'tech-3', name: 'Skyeenet App', type: 'tech', desc: 'Service provider monitoring and customer ticket tracking web platform.', tags: ['Web App', 'REST API', 'MySQL'] },
  { id: 'tech-4', name: 'VIS HR Portal', type: 'tech', desc: 'HR management portal built for Velan Info Services tracking billable hours & performance.', tags: ['PHP', 'CodeIgniter', 'MySQL', 'Bootstrap'] },
  { id: 'tech-5', name: 'PowerBooks Accounting App', type: 'tech', desc: 'Financial bookkeeping application for store revenue, ledger tracking, and invoicing.', tags: ['Laravel', 'PHP', 'MySQL', 'REST API'] },
  { id: 'tech-6', name: 'IDFC Collection Portal', type: 'tech', desc: 'Custom web portal for IDFC collection data requirement gathering and export.', tags: ['Web Dev', 'Database Reporting', 'SQL'] },
  { id: 'tech-7', name: 'Thamizhanda WordPress Website', type: 'tech', desc: 'Content and blogging platform built on custom WordPress setup.', tags: ['WordPress', 'PHP', 'CSS3'] },

  // Game Projects (2)
  { id: 'game-1', name: 'Battle Tanks Game', type: 'game', desc: '2D arcade tank warfare game created with vanilla HTML5 Canvas and ES6 physics engine.', tags: ['HTML5 Canvas', 'JavaScript ES6', 'Game Engine'] },
  { id: 'game-2', name: 'Park A Lot Game', type: 'game', desc: 'Interactive vehicle parking puzzle game with dynamic collision detection.', tags: ['JavaScript', 'Canvas API', 'Interactive Logic'] }
];

// INITIALIZATION
document.addEventListener('DOMContentLoaded', () => {
  renderExecSkills('all');
  renderExecRecruiterTags();
  renderExecProjects('all');
  initGlobalSearch();
  initSkillsFilters();
  initProjectFilters();
  initRecruiterHighlightToggle();
});

// RENDER SKILLS
function renderExecSkills(cat = 'all', query = '') {
  const container = document.getElementById('exec-skills-container');
  if (!container) return;

  container.innerHTML = '';

  const filtered = EXEC_SKILLS.filter(s => {
    const matchCat = (cat === 'all') || (s.cat === cat);
    const matchQuery = query === '' || s.name.toLowerCase().includes(query.toLowerCase());
    return matchCat && matchQuery;
  });

  filtered.forEach(skill => {
    const pill = document.createElement('span');
    const isMatched = query !== '' && skill.name.toLowerCase().includes(query.toLowerCase());
    pill.className = `s-pill ${isMatched ? 'matched-glow' : ''}`;
    pill.textContent = skill.name;
    container.appendChild(pill);
  });
}

// RENDER RECRUITER TAGS
function renderExecRecruiterTags(query = '') {
  const container = document.getElementById('exec-tag-cloud');
  if (!container) return;

  container.innerHTML = '';

  EXEC_RECRUITER_TAGS.forEach(tag => {
    const isMatch = query !== '' && tag.toLowerCase().includes(query.toLowerCase());
    const pill = document.createElement('span');
    pill.className = `r-tag ${isMatch ? 'matched-glow' : ''}`;
    pill.textContent = `# ${tag}`;
    container.appendChild(pill);
  });
}

// RENDER PROJECTS
function renderExecProjects(type = 'all', query = '') {
  const container = document.getElementById('exec-projects-container');
  if (!container) return;

  container.innerHTML = '';

  const filtered = EXEC_PROJECTS.filter(p => {
    const matchType = (type === 'all') || (p.type === type);
    const matchQuery = query === '' || p.name.toLowerCase().includes(query.toLowerCase()) || p.desc.toLowerCase().includes(query.toLowerCase());
    return matchType && matchQuery;
  });

  filtered.forEach(p => {
    const card = document.createElement('div');
    card.className = 'p-card exec-card';

    const tagsHtml = p.tags.map(t => `<span>${t}</span>`).join('');

    card.innerHTML = `
      <h4>${p.name}</h4>
      <p>${p.desc}</p>
      <div class="p-tags">${tagsHtml}</div>
      <button class="btn-sm-outline" onclick="openExecProjectModal('${p.id}')">Details <i data-lucide="external-link"></i></button>
    `;
    container.appendChild(card);
  });

  if (window.lucide) lucide.createIcons();
}

// GLOBAL SEARCH ENGINE
function initGlobalSearch() {
  const input = document.getElementById('exec-global-search');
  if (!input) return;

  input.addEventListener('input', (e) => {
    const q = e.target.value.trim();
    
    const activeSkillCat = document.querySelector('.skills-filter-buttons .s-filter-btn.active')?.dataset.cat || 'all';
    const activeProjCat = document.querySelector('.proj-filter-bar .p-tab.active')?.dataset.pfilter || 'all';

    renderExecSkills(activeSkillCat, q);
    renderExecRecruiterTags(q);
    renderExecProjects(activeProjCat, q);
  });
}

// SKILLS CATEGORY FILTER
function initSkillsFilters() {
  const btns = document.querySelectorAll('.skills-filter-buttons .s-filter-btn');
  btns.forEach(btn => {
    btn.addEventListener('click', () => {
      btns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      const cat = btn.dataset.cat;
      const q = document.getElementById('exec-global-search')?.value.trim() || '';
      renderExecSkills(cat, q);
    });
  });
}

// PROJECTS TYPE FILTER
function initProjectFilters() {
  const tabs = document.querySelectorAll('.proj-filter-bar .p-tab');
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');

      const pfilter = tab.dataset.pfilter;
      const q = document.getElementById('exec-global-search')?.value.trim() || '';
      renderExecProjects(pfilter, q);
    });
  });
}

// RECRUITER HIGHLIGHT TOGGLE
function initRecruiterHighlightToggle() {
  const btn = document.getElementById('recruiter-highlight-btn');
  if (!btn) return;

  btn.addEventListener('click', () => {
    document.body.classList.toggle('recruiter-mode-active');
    btn.classList.toggle('active');
  });
}

// MODAL CONTROLS
function openContactModal() {
  const d = document.getElementById('exec-contact-dialog');
  if (d && typeof d.showModal === 'function') d.showModal();
}

function closeContactModal() {
  const d = document.getElementById('exec-contact-dialog');
  if (d && typeof d.close === 'function') d.close();
}

function openExecProjectModal(projId) {
  const d = document.getElementById('exec-project-dialog');
  const title = document.getElementById('exec-proj-title');
  const body = document.getElementById('exec-proj-body');

  const p = EXEC_PROJECTS.find(item => item.id === projId);
  if (!p || !d) return;

  title.textContent = p.name;
  body.innerHTML = `
    <p class="margin-top-xs" style="color:var(--text-secondary); font-size:0.95rem;">${p.desc}</p>
    <div class="margin-top-md">
      <strong>Category:</strong> ${p.type.toUpperCase()}
    </div>
    <div class="margin-top-sm">
      <strong>Technologies & Methodologies:</strong>
      <div class="p-tags margin-top-xs">${p.tags.map(t => `<span>${t}</span>`).join('')}</div>
    </div>
  `;

  d.showModal();
}

function closeProjectModal() {
  const d = document.getElementById('exec-project-dialog');
  if (d && typeof d.close === 'function') d.close();
}

function copyText(text, btn) {
  navigator.clipboard.writeText(text).then(() => {
    const orig = btn.textContent;
    btn.textContent = 'Copied!';
    setTimeout(() => btn.textContent = orig, 2000);
  });
}
